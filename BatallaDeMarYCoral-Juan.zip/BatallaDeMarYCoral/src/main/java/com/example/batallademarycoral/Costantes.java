package com.example.batallademarycoral;

public class Costantes {
    public static final double ANCHO_VENTANA = 988;
    public static final double ALTO_VENTANA = 730;
}